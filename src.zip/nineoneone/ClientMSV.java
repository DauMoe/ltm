/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package nineoneone;



import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;


import java.net.Socket;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author nhuva
 */
public class ClientMSV {
    static int UCLN(int a,int b){
        if(a==0||b==0) return 0;
        while(a!=b){
                if(a>b) a-=b;
                if(b>a) b-=a;
        } 
        return a;
    }
    public static void main(String[] args) {
        DataInputStream inp;
        DataOutputStream out;
        String msv="B16DCCN006,911";
        int a,b,ucln,bcnn,tong,tich;
        try {
            Socket client=new Socket("localhost",1110);
            out=new DataOutputStream(client.getOutputStream());
            out.writeUTF(msv);
            inp=new DataInputStream(client.getInputStream());
            a=inp.readInt();
            b=inp.readInt();
            ucln=UCLN(a,b);
            if(ucln !=0) bcnn=(a*b)/ucln;
            else bcnn=0;
            tong=a+b;
            tich=a*b;
            
            out.writeInt(ucln);
            out.writeInt(bcnn);
            out.writeInt(tong);
            out.writeInt(tich);
            inp.close();
            out.close();
            client.close();
        } catch (IOException ex) {
            Logger.getLogger(ClientMSV.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}
