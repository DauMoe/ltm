/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package nineonetwo;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.Socket;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author dell 5548
 */
public class SClient {

    private Socket socket;
    private BufferedWriter bw;
    private BufferedReader br;
    private StringBuilder str1 = new StringBuilder();
    private StringBuilder str2 = new StringBuilder();

    public SClient() {
        connect();
    }

    private void connect() {
        try {
            StringBuilder result = new StringBuilder();
            String str = "B16DCCN284;701";
            socket = new Socket("localhost", 1108);
            br = new BufferedReader(new InputStreamReader(socket.getInputStream()));
            bw = new BufferedWriter(new OutputStreamWriter(socket.getOutputStream()));
            bw.write(str);
            bw.newLine();
            bw.flush();
            str = br.readLine();
            System.out.println(str);
            xuLy(str);
            System.out.println(str1.toString() + "\n" + str2.toString());
            bw.write(str1.toString());
            bw.newLine();
            bw.flush();
            bw.write(str2.toString());
            bw.newLine();
            bw.flush();
        } catch (Exception ex) {
            ex.printStackTrace();
        } finally {
            try {
                bw.close();
                br.close();
                socket.close();
            } catch (IOException ex) {
                Logger.getLogger(SClient.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    private void xuLy(String str) {
        for (int i = 0; i < str.length(); i++) {
            int temp = (int) str.charAt(i);
            if ((45 <= temp && temp <= 57) || (65 <= temp && temp <= 90) || (97 <= temp && temp <= 122)) {
                str1.append(str.charAt(i));
            } else {
                str2.append(str.charAt(i));
            }
        }
    }

    public static void main(String[] args) {
        new SClient();

    }
}
